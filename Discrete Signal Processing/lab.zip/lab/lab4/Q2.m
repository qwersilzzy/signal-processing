wp1=0.65*pi;
wp2=0.75*pi;
ws1=0.6*pi;
ws2=0.8*pi;
ap=0.2;
as=42;
dw1=wp1-ws1;
dw2=ws2-wp2;
dw=min(dw1,dw2);
wc1=mean([ws1 wp1]);
wc2=mean([ws2 wp2]);
N=2*ceil((3.32*pi)/dw);
b=fir1(N,[wc1/pi wc2/pi]);
[H,w]=freqz(b,1,512);
figure(1)
subplot(1,2,1);
stem(b);
title('impulse response coefficient');
xlabel('time index n');
ylabel('h[n]');
subplot(1,2,2)
plot(w/pi,20*log10(abs(H)));
grid on
xlabel('w/pi');
ylabel('gain in dB');
title('hamming');

