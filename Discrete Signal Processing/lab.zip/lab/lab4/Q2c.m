wp1=0.65*pi;
wp2=0.75*pi;
ws1=0.6*pi;
ws2=0.8*pi;
ap=0.2;
as=42;
dw1=wp1-ws1;
dw2=ws2-wp2;
dw=min(dw1,dw2);
wc1=mean([ws1 wp1]);
wc2=mean([ws2 wp2]);

ds=10^(-as/20);
dp=10^(-ap/20);
[N,wn,beta,type]=kaiserord([wc1/pi wc2/pi],[1 0],[dp ds]);
b=fir1(2*N,[wc1/pi wc2/pi],kaiser(2*N+1,beta));
[H,w]=freqz(b,1,512);
figure(3)
subplot(1,2,1);
stem(b);
title('impulse response coefficient');
xlabel('time index n');
ylabel('h[n]');
subplot(1,2,2)
plot(w/pi,20*log10(abs(H)));
grid on
xlabel('w/pi');
ylabel('gain in dB');
title('kaiser');



