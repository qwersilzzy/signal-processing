n=0:50;
xn=sin(5*pi/16*n);
yn=xn.*xn;
energy=sum(yn);
figure(1)
stem(n,xn);
title('the graph of xn')
