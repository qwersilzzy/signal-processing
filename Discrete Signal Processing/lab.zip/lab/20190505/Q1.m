L=input('input the L = ');
r=[10/4 -8/2];%the nominator 
p=[-1/4 -1/2];%the pole for z
k=[-2];%the constant
[B,A]=residuez(r,p,k);
[h t]=impz(B,A,L);
stem(t,h);
title('L=50');