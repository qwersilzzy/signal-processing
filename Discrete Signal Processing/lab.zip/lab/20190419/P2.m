B=[0.15,0,-0.15];
A=[1,-0.5,0.7];
[H,w]=freqz(B,A,512);
w=0:pi/511:pi;
plot(w,abs(H));