B=[1.35,4.95,8.55,4.95,1.8];
A=[0.9,-1.8,1.65,-0.75,0.15];
[H,w]=freqz(B,A,1024);
w=0:pi/1023:pi;
figure(1)
subplot(2,1,1);
plot(abs(H));
title('real part');
subplot(2,1,2);
plot(unwrap(angle(H)));
title('imaginary part');


