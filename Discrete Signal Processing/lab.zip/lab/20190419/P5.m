Fs=20;
t=0:(1/Fs):(64*1/Fs);
x1t=sin(0.1*pi*t);
x2t=2*cos(0.3*pi*t);
x3t=3*sin(0.5*pi*t);
xt=x1t+x2t+x3t;
X=fft(xt);
figure(1)
subplot(2,1,1);
plot(abs(X));
title('real part');
subplot(2,1,2);
plot(angle(X));
title('imaginary part');

