num=[0.15 0 -0.15];
den=[1 -0.5 0.7];
[h,w]=freqz(num,den);
plot(w/pi,abs(h));