n=0:10;
g=cos(0.2*pi*n);
h=3.^n;
y=conv(g,h);
n1=0:length(y)-1;
stem(n1,y);