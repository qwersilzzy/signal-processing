%using DFT
n=0:31;
x=sin(pi*n/4);
y1=zeros(1,128);
for k=1:128
    y=0;
    for n=1:32
        y=y+x(n)*exp(-j*2*pi*(k-1)*(n-1)/128);
    end
    y1(k)=y;
end
k=1:128;
subplot(2,1,1)
plot(k,y1)
%using MATLAB function
n1=0:31;
x2=sin(pi*n1/4);
y2=fft(x2,128);
subplot(2,1,2)
plot(k,y2)