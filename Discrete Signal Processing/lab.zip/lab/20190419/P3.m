n=0:10;
gn=cos(0.2*pi*n);
hn=power(3,n);
yn=conv(gn,hn);
plot(yn);

