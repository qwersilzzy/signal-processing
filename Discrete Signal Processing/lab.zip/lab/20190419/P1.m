n=0:127;
gn1=sin(pi*n/4);
gn=sin(pi*n/4).*[ones(1,32) zeros(1,96)];
N=128;
k=0:127;
G1=fft(gn,128);
t=0;
while t<128
    G22=sin(pi*t/4).*exp(-1i*2*pi*k*t/N);
    t=t+1;
    G2=G22+sin(pi*t/4).*exp(-1i*2*pi*k*t/N);
    
end
figure(1);
subplot(2,2,1);
stem(abs(G1));
axis([0 128 -inf inf]);
title('matlab result of real part');
subplot(2,2,2);
stem(abs(G2));
axis([0 128 -inf inf]);
title('definition of real part');
subplot(2,2,3);
stem(angle(G1));
axis([0 128 -inf inf]);
title('matlab result of imaginary part');
subplot(2,2,4);
stem(angle(G2));
axis([0 128 -inf inf]);
title('definition of imaginary part');

figure(2)
stem(G1);
hold on
stem(G2);
hold off 
axis([0 128 -1 1]);



