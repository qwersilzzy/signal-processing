[n,wn,beta,typ]=kaiserord([2000 2500],[1 0],[0.005 0.005],10000); 
b=fir1(n,wn,kaiser(n+1,beta),'noscale'); 
[h,omega]=freqz(b,1,256); 
subplot(2,1,1) 
plot(omega/pi,20*log10(abs(h)));
xlabel('\omega/\pi');
ylabel('Gain, dB'); 
subplot(2,1,2) 
plot(omega/pi,angle(h));
grid 
title('Phase Spectrum')
xlabel('\omega/\pi'); 
ylabel('Phase, radians') 
