z=input('input the zeros=');
p=input('input the ploes='); 
g=input('input the gain constant='); 
[num,den]=zp2tf(z',p',g);
w = 0:pi/(255):pi; 
h=freqz(num,den,w); 
subplot(2,1,1) 
plot(w/pi,abs(h));
grid%dashline etc
title('Magnitude Spectrum') 
xlabel('\omega/\pi');
ylabel('Magnitude') 
subplot(2,1,2) 
plot(w/pi,angle(h));
grid 
title('Phase Spectrum') 
xlabel('\omega/\pi');
ylabel('Phase, radians') 
