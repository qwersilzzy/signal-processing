num=[4 15.6 6 2.4 -6.4]; 
den=[3 2.4 6.3 -11.4 6]; 
[sos,G]=tf2sos(num,den);%sos=second-order-section
[z,p,k]=tf2zp(num,den);
zplane(z,p); 